package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	WebDriver driver;
	
	@Given("^Open browser and enter the icopmpass URL$")
	public void open_browser_and_enter_the_icopmpass_URL() throws Throwable {
		
		
		String path =  "C:\\Users\\hripatil\\Downloads\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		driver = new ChromeDriver();			//browswer opens
		
		String url = "https://icompassweb.fs.capgemini.com";
	
		driver.get(url);
	   
	}
	
	

	@When("^user enters valid user name \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void user_enters_valid_user_name_and_password(String username, String password) throws Throwable {
		
		WebElement userField =	driver.findElement(By.id("userName"));			//id of username on site
		WebElement passwordTextField =	driver.findElement(By.id("password"));	// id of password on site
		
		userField.sendKeys(username);
		passwordTextField.sendKeys(password);
	  
	
	
	}
	
	

	@Then("^Successfully lopgin to icompass$")
	public void successfully_lopgin_to_icompass() throws Throwable {
		
		WebElement loginButton =	driver.findElement(By.id("loginButton"));
		loginButton.click();
	   
	}

	

}
