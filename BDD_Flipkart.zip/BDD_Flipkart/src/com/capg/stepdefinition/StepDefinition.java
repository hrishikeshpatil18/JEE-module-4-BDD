package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	  WebDriver driver;
	    
	    @Given("^Open Any Browser and enter Flipkart URL$")
	    public void open_Any_Browser_and_enter_Flipkart_URL() throws Throwable {
	      
	        String path = "C:\\\\Users\\\\hripatil\\\\Downloads\\\\chromedriver.exe";
	        
	        System.setProperty("webdriver.chrome.driver",path);
	        
	        
	        driver = new ChromeDriver();
	        String url = "https://www.flipkart.com";
	        
	        driver.get(url);
	        
	    }

	 

	    @When("^User Enter valid username \"([^\"]*)\"$")
	    public void user_Enter_valid_username(String username) throws Throwable {
	        //WebElement loginField = driver.findElement(By.className("dHGf8H"));
	        WebElement userField = driver.findElement(By.className("_2zrpKA"));
	        
	        //loginField.click();
	        userField.sendKeys(username);
	        
	    }

	 

	    @Then("^Get OTP to Login successfully$")
	    public void get_OTP_to_Login_successfully() throws Throwable {
	        WebElement requestField = driver.findElement(By.className("jUwFiZ"));
	        
	        requestField.click();
	    }
	
	

}
